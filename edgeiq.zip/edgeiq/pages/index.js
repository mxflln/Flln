import { useState, useEffect, useRef } from "react";
import Head from "next/head";

const fmt$ = (n) => n >= 1e6 ? `$${(n/1e6).toFixed(2)}M` : `$${(n/1e3).toFixed(0)}k`;
const fmtBig = (n) => n >= 1e6 ? `$${(n/1e6).toFixed(1)}M` : `$${(n/1e3).toFixed(0)}k`;

const LEADS = [
  { id:1, name:"Sarah Mitchell",       initials:"SM", suburb:"Paddington",  type:"Seller", score:94, property:"4BR House",     value:1200000, lastContact:"Today",      notes:"Relocating interstate – highly motivated", phone:"0412 555 001", email:"sarah.m@email.com" },
  { id:2, name:"James & Priya Okafor", initials:"JP", suburb:"Ascot",       type:"Buyer",  score:87, property:"3BR House",     value:850000,  lastContact:"Yesterday",   notes:"Pre-approved, missed 3 auctions in a row",  phone:"0412 555 002", email:"jp.okafor@email.com" },
  { id:3, name:"Derek Nguyen",         initials:"DN", suburb:"New Farm",    type:"Seller", score:71, property:"2BR Apartment", value:590000,  lastContact:"5 days ago",  notes:"Divorce settlement – timeline unclear",    phone:"0412 555 003", email:"derek.n@email.com" },
  { id:4, name:"Carolyn Bates",        initials:"CB", suburb:"Clayfield",   type:"Buyer",  score:63, property:"Townhouse",     value:720000,  lastContact:"1 week ago",  notes:"Browsing casually, not urgent yet",        phone:"0412 555 004", email:"carolyn.b@email.com" },
  { id:5, name:"Marcus Webb",          initials:"MW", suburb:"Hamilton",    type:"Seller", score:41, property:"5BR House",     value:1800000, lastContact:"3 weeks ago", notes:"Considering selling next financial year",  phone:"0412 555 005", email:"marcus.w@email.com" },
  { id:6, name:"Tina Rosario",         initials:"TR", suburb:"Bulimba",     type:"Buyer",  score:78, property:"3BR Townhouse", value:690000,  lastContact:"2 days ago",  notes:"Cash buyer, wants quick settlement",       phone:"0412 555 006", email:"tina.r@email.com" },
];

const PIPELINE = [
  { stage:"Appraisal",   count:8,  value:6800000,  color:"#f97316" },
  { stage:"Listed",      count:12, value:10200000, color:"#eab308" },
  { stage:"Under Offer", count:5,  value:4100000,  color:"#22c55e" },
  { stage:"Exchanged",   count:3,  value:2400000,  color:"#06b6d4" },
  { stage:"Settled",     count:23, value:18900000, color:"#8b5cf6" },
];

const SUBURBS = ["Paddington","Ascot","New Farm","Clayfield","Hamilton","Bulimba","Teneriffe","Fortitude Valley","West End","South Brisbane"];

async function streamAPI(endpoint, body, onChunk) {
  const res = await fetch(`/api/${endpoint}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let full = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    const lines = decoder.decode(value).split("\n");
    for (const line of lines) {
      if (!line.startsWith("data: ")) continue;
      const data = line.slice(6);
      if (data === "[DONE]") return full;
      try {
        const parsed = JSON.parse(data);
        if (parsed.error) throw new Error(parsed.error);
        if (parsed.text) { full += parsed.text; onChunk(full); }
      } catch {}
    }
  }
  return full;
}

function Avatar({ initials, size = 38, glow }) {
  const colors = { S:"#f97316",J:"#06b6d4",D:"#8b5cf6",C:"#ec4899",M:"#22c55e",T:"#eab308" };
  const c = colors[initials[0]] || "#6366f1";
  return (
    <div style={{
      width:size, height:size, borderRadius:"50%",
      background:`radial-gradient(circle at 35% 35%, ${c}dd, ${c}55)`,
      display:"flex", alignItems:"center", justifyContent:"center",
      fontSize:size*0.33, fontWeight:800, color:"#fff", flexShrink:0,
      boxShadow: glow ? `0 0 20px ${c}80` : `0 2px 8px ${c}40`,
      border:`1.5px solid ${c}33`, letterSpacing:"0.5px",
    }}>{initials}</div>
  );
}

function ScoreRing({ score }) {
  const color = score>=80?"#22c55e":score>=60?"#f97316":"#6b7280";
  const r=16, circ=2*Math.PI*r, dash=(score/100)*circ;
  return (
    <div style={{ position:"relative", width:40, height:40, flexShrink:0 }}>
      <svg width="40" height="40" style={{ transform:"rotate(-90deg)" }}>
        <circle cx="20" cy="20" r={r} fill="none" stroke="#1a1a2e" strokeWidth="3"/>
        <circle cx="20" cy="20" r={r} fill="none" stroke={color} strokeWidth="3"
          strokeDasharray={`${dash} ${circ}`} strokeLinecap="round"
          style={{ filter:`drop-shadow(0 0 4px ${color})` }}/>
      </svg>
      <div style={{ position:"absolute", inset:0, display:"flex", alignItems:"center", justifyContent:"center",
        fontSize:11, fontWeight:800, color, fontFamily:"monospace" }}>{score}</div>
    </div>
  );
}

function Spinner() {
  return <div style={{ width:14, height:14, border:"2px solid #4f46e5", borderTop:"2px solid transparent", borderRadius:"50%", animation:"spin 0.7s linear infinite", display:"inline-block" }}/>;
}

export default function EdgeIQ() {
  const [tab, setTab] = useState("radar");
  const [selectedLead, setSelectedLead] = useState(null);
  const [aiMessage, setAiMessage] = useState("");
  const [aiStreaming, setAiStreaming] = useState(false);
  const [aiInsight, setAiInsight] = useState("");
  const [insightStreaming, setInsightStreaming] = useState(false);
  const [prediction, setPrediction] = useState("");
  const [predicting, setPredicting] = useState(false);
  const [suburbData, setSuburbData] = useState({});
  const [loadingSuburb, setLoadingSuburb] = useState(null);
  const [selectedSuburb, setSelectedSuburb] = useState("Paddington");
  const [stats, setStats] = useState({ commission:0, volume:0, leads:0, days:0 });
  const [tone, setTone] = useState("professional");
  const [copied, setCopied] = useState(false);
  const [toast, setToast] = useState(null);
  const msgRef = useRef(null);

  useEffect(() => {
    const t = { commission:284750, volume:42400000, leads:51, days:23 };
    let f=0;
    const id = setInterval(()=>{
      f++; const p=1-Math.pow(1-f/70,3);
      setStats({ commission:Math.round(t.commission*p), volume:Math.round(t.volume*p), leads:Math.round(t.leads*p), days:Math.round(t.days*p) });
      if(f>=70) clearInterval(id);
    },18);
    return ()=>clearInterval(id);
  },[]);

  useEffect(() => { loadSuburb(selectedSuburb); }, [selectedSuburb]);

  const showToast = (msg, color="#22c55e") => {
    setToast({ msg, color });
    setTimeout(()=>setToast(null), 3000);
  };

  const loadSuburb = async (suburb) => {
    if (suburbData[suburb]) return;
    setLoadingSuburb(suburb);
    try {
      const res = await fetch("/api/suburb", { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({ suburb }) });
      const data = await res.json();
      setSuburbData(prev => ({ ...prev, [suburb]: data }));
    } catch {}
    setLoadingSuburb(null);
  };

  const generateMessage = async () => {
    if (!selectedLead || aiStreaming) return;
    setAiStreaming(true); setAiMessage("");
    try {
      await streamAPI("message", { lead: selectedLead, tone }, setAiMessage);
    } catch(e) { setAiMessage(`Error: ${e.message}`); }
    finally { setAiStreaming(false); }
  };

  const generateInsight = async () => {
    if (!selectedLead || insightStreaming) return;
    setInsightStreaming(true); setAiInsight("");
    try {
      await streamAPI("insight", { lead: selectedLead }, setAiInsight);
    } catch(e) { setAiInsight(`Error: ${e.message}`); }
    finally { setInsightStreaming(false); }
  };

  const runPrediction = async () => {
    if (predicting) return;
    setPredicting(true); setPrediction("");
    try {
      await streamAPI("predict", { leads: LEADS }, setPrediction);
    } catch(e) { setPrediction(`Error: ${e.message}`); }
    finally { setPredicting(false); }
  };

  const intel = suburbData[selectedSuburb];

  return (
    <>
      <Head>
        <title>EdgeIQ — AI Agent Platform</title>
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700;800&family=Syne:wght@700;800&display=swap" rel="stylesheet"/>
      </Head>

      <style jsx global>{`
        * { box-sizing:border-box; margin:0; padding:0; }
        body { background:#07070f; color:#ddd8ff; font-family:'DM Sans',sans-serif; overflow-x:hidden; }
        ::-webkit-scrollbar { width:3px; height:3px; }
        ::-webkit-scrollbar-track { background:transparent; }
        ::-webkit-scrollbar-thumb { background:#2a2a4a; border-radius:2px; }
        @keyframes fadeUp { from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:translateY(0)} }
        @keyframes spin { to{transform:rotate(360deg)} }
        @keyframes ticker { 0%{transform:translateX(0)} 100%{transform:translateX(-50%)} }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.3} }
        @keyframes ripple { 0%{box-shadow:0 0 0 0 currentColor} 70%{box-shadow:0 0 0 8px transparent} 100%{box-shadow:0 0 0 0 transparent} }
        .lead-card { transition:all 0.18s; cursor:pointer; }
        .lead-card:hover { background:#0e0e22 !important; border-color:#2a2a5a !important; transform:translateY(-1px); }
        .tab-btn { transition:all 0.2s; border-bottom:2px solid transparent; }
        .tab-btn:hover { color:#a5b4fc !important; }
        .tab-btn.active { border-bottom:2px solid #4f46e5; color:#a5b4fc !important; }
        .chip:hover { border-color:#6366f1 !important; color:#a5b4fc !important; }
        .action-btn { transition:all 0.18s; }
        .action-btn:hover { opacity:0.85; transform:translateY(-1px); }
        .tone-btn { transition:all 0.18s; cursor:pointer; }
        .tone-btn:hover { border-color:#4f46e5 !important; }
        .tone-btn.active { background:#1e1b4b !important; border-color:#4f46e5 !important; color:#a5b4fc !important; }
      `}</style>

      {/* Toast */}
      {toast && (
        <div style={{ position:"fixed", top:16, left:"50%", transform:"translateX(-50%)", zIndex:9999,
          background:"#0d0d1f", border:`1px solid ${toast.color}44`, borderRadius:12,
          padding:"10px 20px", fontSize:13, color:toast.color, fontWeight:700,
          boxShadow:"0 8px 32px #000a", animation:"fadeUp 0.3s ease", whiteSpace:"nowrap" }}>
          {toast.msg}
        </div>
      )}

      {/* Header */}
      <header style={{ position:"sticky", top:0, zIndex:100, background:"rgba(7,7,15,0.95)",
        backdropFilter:"blur(20px)", borderBottom:"1px solid #1a1a30",
        padding:"14px 24px", display:"flex", alignItems:"center", justifyContent:"space-between" }}>
        <div style={{ display:"flex", alignItems:"center", gap:12 }}>
          <div style={{ width:34, height:34, borderRadius:10, background:"linear-gradient(135deg,#4f46e5,#7c3aed)",
            display:"flex", alignItems:"center", justifyContent:"center", fontSize:16,
            boxShadow:"0 0 24px #4f46e560" }}>⚡</div>
          <div>
            <div style={{ fontFamily:"'Syne',sans-serif", fontSize:18, fontWeight:800,
              background:"linear-gradient(90deg,#fff,#a5b4fc)", WebkitBackgroundClip:"text",
              WebkitTextFillColor:"transparent", letterSpacing:"-0.5px" }}>EDGEIQ</div>
            <div style={{ fontSize:9, color:"#4f46e5", fontWeight:700, letterSpacing:"2.5px" }}>AI AGENT PLATFORM</div>
          </div>
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:8 }}>
          <span style={{ width:7, height:7, borderRadius:"50%", background:"#22c55e",
            boxShadow:"0 0 8px #22c55e", display:"inline-block", animation:"ripple 1.4s infinite", color:"#22c55e" }}/>
          <span style={{ fontSize:11, color:"#6b6b9a", fontWeight:600 }}>Live AI</span>
          <div style={{ marginLeft:8, display:"flex", alignItems:"center", gap:8, background:"#0d0d1f",
            border:"1px solid #1a1a30", borderRadius:20, padding:"5px 12px" }}>
            <Avatar initials="RC" size={20}/>
            <span style={{ fontSize:12, color:"#a5b4fc", fontWeight:600 }}>Rebecca Chen</span>
          </div>
        </div>
      </header>

      {/* Ticker */}
      <div style={{ background:"#0a0a1a", borderBottom:"1px solid #1a1a30", overflow:"hidden", height:26, display:"flex", alignItems:"center" }}>
        <div style={{ display:"flex", animation:"ticker 35s linear infinite", whiteSpace:"nowrap" }}>
          {[...Array(2)].map((_,x)=>(
            <span key={x} style={{ display:"inline-flex", gap:40, padding:"0 20px", fontSize:10, color:"#4a4870", fontWeight:600 }}>
              {["🏠 Paddington +7.2% QoQ","🔥 Ascot median $1.42M","⚡ New Farm 15 days avg","📈 Hamilton clearance 84%","💰 Bulimba $920k median","🎯 Teneriffe +11.2% YoY","💎 Fortitude Valley yield 5.1%"].map((t,i)=>(
                <span key={i}>{t}</span>
              ))}
            </span>
          ))}
        </div>
      </div>

      {/* Stats */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:1, background:"#1a1a30", borderBottom:"1px solid #1a1a30" }}>
        {[
          { label:"YTD Commission", value:`$${(stats.commission/1000).toFixed(0)}k`, sub:"↑ 23% vs LY", color:"#22c55e", icon:"💰" },
          { label:"Pipeline", value:fmtBig(stats.volume), sub:"41 listings", color:"#a78bfa", icon:"📊" },
          { label:"Active Leads", value:stats.leads, sub:"6 urgent today", color:"#f97316", icon:"🎯" },
          { label:"Avg Days Listed", value:`${stats.days}d`, sub:"Mkt avg: 41d", color:"#06b6d4", icon:"⚡" },
        ].map((s,i)=>(
          <div key={i} style={{ background:"#07070f", padding:"14px 16px", animation:"fadeUp 0.4s ease both", animationDelay:`${i*0.08}s` }}>
            <div style={{ fontSize:9, color:"#4a4870", fontWeight:700, letterSpacing:"0.8px", textTransform:"uppercase", marginBottom:3 }}>{s.label}</div>
            <div style={{ fontSize:20, fontWeight:800, color:"#fff", fontFamily:"'Syne',sans-serif" }}>{s.value}</div>
            <div style={{ fontSize:10, color:s.color, marginTop:2, fontWeight:600 }}>{s.sub}</div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div style={{ display:"flex", borderBottom:"1px solid #1a1a30", padding:"0 24px", background:"#07070f" }}>
        {[
          {id:"radar",label:"🎯 Lead Radar"},
          {id:"intel",label:"📡 Market Intel"},
          {id:"outreach",label:"✉️ AI Outreach"},
          {id:"predict",label:"🔮 Predict"},
        ].map(t=>(
          <button key={t.id} className={`tab-btn${tab===t.id?" active":""}`}
            onClick={()=>setTab(t.id)}
            style={{ padding:"13px 18px", background:"none", border:"none", borderBottom:"2px solid transparent",
              color:tab===t.id?"#a5b4fc":"#4a4870", fontSize:12, fontWeight:700, cursor:"pointer",
              fontFamily:"'DM Sans',sans-serif", letterSpacing:"0.3px" }}>
            {t.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <main style={{ padding:"20px 24px 60px", maxWidth:900, margin:"0 auto" }}>

        {/* RADAR */}
        {tab==="radar" && (
          <div style={{ animation:"fadeUp 0.3s ease" }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:14 }}>
              <span style={{ fontSize:11, color:"#4a4870", fontWeight:600 }}>Ranked by AI transaction probability</span>
              <span style={{ fontSize:10, color:"#22c55e", fontWeight:700 }}>● Live scoring</span>
            </div>
            <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
              {LEADS.map((lead,i)=>(
                <div key={lead.id} className="lead-card"
                  onClick={()=>{ setSelectedLead(lead); setTab("outreach"); setAiMessage(""); setAiInsight(""); }}
                  style={{ background:"#0a0a1a", border:"1px solid #1a1a30", borderRadius:16,
                    padding:"14px 16px", display:"flex", gap:12, alignItems:"center",
                    animation:"fadeUp 0.35s ease both", animationDelay:`${i*0.05}s` }}>
                  <Avatar initials={lead.initials} glow={lead.score>=80}/>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:3, flexWrap:"wrap" }}>
                      <span style={{ fontSize:14, fontWeight:700, color:"#e8e4ff", fontFamily:"'Syne',sans-serif" }}>{lead.name}</span>
                      <span style={{ fontSize:9, padding:"2px 8px", borderRadius:10, fontWeight:800, letterSpacing:"0.8px",
                        background:lead.type==="Seller"?"#1e0d30":"#0d1e30",
                        color:lead.type==="Seller"?"#c084fc":"#60a5fa",
                        border:`1px solid ${lead.type==="Seller"?"#c084fc25":"#60a5fa25"}` }}>
                        {lead.type.toUpperCase()}
                      </span>
                      {lead.score>=80 && <span style={{ fontSize:9, padding:"2px 7px", borderRadius:10, background:"#0d2010", color:"#22c55e", border:"1px solid #22c55e25", fontWeight:800 }}>🔥 HOT</span>}
                    </div>
                    <div style={{ fontSize:12, color:"#4a4870", marginBottom:2 }}>{lead.suburb} · {lead.property} · <span style={{ color:"#7c7a9e" }}>{fmt$(lead.value)}</span></div>
                    <div style={{ fontSize:11, color:"#3a3860", fontStyle:"italic", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>"{lead.notes}"</div>
                  </div>
                  <ScoreRing score={lead.score}/>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* INTEL */}
        {tab==="intel" && (
          <div style={{ animation:"fadeUp 0.3s ease" }}>
            <div style={{ fontSize:11, color:"#4a4870", fontWeight:600, marginBottom:14 }}>Live market intelligence · AI-powered</div>
            <div style={{ display:"flex", gap:8, flexWrap:"wrap", marginBottom:18 }}>
              {SUBURBS.map(s=>(
                <button key={s} className="chip"
                  onClick={()=>{ setSelectedSuburb(s); loadSuburb(s); }}
                  style={{ padding:"6px 12px", borderRadius:20, fontSize:11, fontWeight:700, cursor:"pointer",
                    background:selectedSuburb===s?"#1e1b4b":"#0d0d1f",
                    border:`1px solid ${selectedSuburb===s?"#4f46e5":"#1a1a30"}`,
                    color:selectedSuburb===s?"#a5b4fc":"#4a4870",
                    fontFamily:"'DM Sans',sans-serif", transition:"all 0.2s" }}>
                  {s}
                </button>
              ))}
            </div>

            <div style={{ background:"#0d0d1f", border:"1px solid #1a1a30", borderRadius:16, padding:20, marginBottom:16 }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16 }}>
                <span style={{ fontFamily:"'Syne',sans-serif", fontSize:18, fontWeight:800, color:"#fff" }}>{selectedSuburb}</span>
                {loadingSuburb===selectedSuburb ? (
                  <span style={{ display:"flex", alignItems:"center", gap:6, fontSize:11, color:"#4f46e5" }}><Spinner/> Fetching live data...</span>
                ) : intel ? (
                  <span style={{ fontSize:10, color:"#22c55e", fontWeight:700 }}>● Live</span>
                ) : null}
              </div>
              {intel ? (
                <div style={{ animation:"fadeUp 0.3s ease" }}>
                  <div style={{ display:"grid", gridTemplateColumns:"repeat(2,1fr)", gap:10, marginBottom:14 }}>
                    {[
                      { label:"Median Price", value:fmt$(intel.median), color:"#a78bfa" },
                      { label:"Growth", value:intel.growth, color:"#22c55e" },
                      { label:"Avg Days Listed", value:`${intel.days} days`, color:"#06b6d4" },
                      { label:"Clearance Rate", value:intel.clearance, color:"#f97316" },
                    ].map((m,i)=>(
                      <div key={i} style={{ background:"#07070f", borderRadius:12, padding:"14px 16px", border:"1px solid #1a1a30",
                        animation:"fadeUp 0.3s ease both", animationDelay:`${i*0.05}s` }}>
                        <div style={{ fontSize:9, color:"#4a4870", fontWeight:700, textTransform:"uppercase", letterSpacing:"0.8px", marginBottom:4 }}>{m.label}</div>
                        <div style={{ fontSize:22, fontWeight:800, color:m.color, fontFamily:"'Syne',sans-serif" }}>{m.value}</div>
                      </div>
                    ))}
                  </div>
                  <div style={{ background:"#07070f", borderRadius:12, padding:"14px 16px", border:"1px solid #1a1a30" }}>
                    <div style={{ fontSize:9, color:"#4f46e5", fontWeight:700, letterSpacing:"1.5px", marginBottom:6 }}>🧠 AI MARKET INSIGHT</div>
                    <div style={{ fontSize:13, color:"#9996cc", lineHeight:1.7 }}>{intel.insight}</div>
                  </div>
                </div>
              ) : (
                <div style={{ display:"flex", flexDirection:"column", alignItems:"center", padding:"32px 0", gap:12 }}>
                  <Spinner/>
                  <div style={{ fontSize:12, color:"#4a4870" }}>Loading market data...</div>
                </div>
              )}
            </div>

            {/* Pipeline */}
            <div style={{ background:"#0d0d1f", border:"1px solid #1a1a30", borderRadius:16, padding:20 }}>
              <div style={{ fontSize:9, color:"#4f46e5", fontWeight:700, letterSpacing:"1.5px", marginBottom:14 }}>📊 YOUR PIPELINE · $42.4M TOTAL</div>
              {PIPELINE.map((s,i)=>(
                <div key={i} style={{ marginBottom:14, animation:"fadeUp 0.3s ease both", animationDelay:`${i*0.06}s` }}>
                  <div style={{ display:"flex", justifyContent:"space-between", marginBottom:6 }}>
                    <div style={{ display:"flex", gap:8, alignItems:"center" }}>
                      <span style={{ fontSize:13, fontWeight:600, color:"#ddd8ff" }}>{s.stage}</span>
                      <span style={{ fontSize:10, background:"#1a1a30", borderRadius:8, padding:"1px 7px", color:"#6b6b9a", fontWeight:700 }}>{s.count}</span>
                    </div>
                    <span style={{ fontSize:13, color:s.color, fontWeight:800 }}>{fmtBig(s.value)}</span>
                  </div>
                  <div style={{ height:5, background:"#1a1a30", borderRadius:3, overflow:"hidden" }}>
                    <div style={{ height:"100%", width:`${(s.count/23)*100}%`, borderRadius:3,
                      background:`linear-gradient(90deg,${s.color},${s.color}66)`,
                      boxShadow:`0 0 8px ${s.color}50`, transition:"width 1.2s cubic-bezier(0.4,0,0.2,1)" }}/>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* OUTREACH */}
        {tab==="outreach" && (
          <div style={{ animation:"fadeUp 0.3s ease" }}>
            {/* Lead picker */}
            <div style={{ display:"flex", gap:8, overflowX:"auto", paddingBottom:10, marginBottom:16 }}>
              {LEADS.map(l=>(
                <button key={l.id} onClick={()=>{ setSelectedLead(l); setAiMessage(""); setAiInsight(""); }}
                  style={{ flexShrink:0, padding:"7px 14px", borderRadius:20, cursor:"pointer",
                    background:selectedLead?.id===l.id?"#1e1b4b":"#0d0d1f",
                    border:`1px solid ${selectedLead?.id===l.id?"#4f46e5":"#1a1a30"}`,
                    color:selectedLead?.id===l.id?"#a5b4fc":"#6b6b9a",
                    fontSize:11, fontWeight:700, fontFamily:"'DM Sans',sans-serif", transition:"all 0.2s" }}>
                  {l.name.split(" ")[0]} <span style={{ opacity:0.6, fontSize:10 }}>{l.score}</span>
                </button>
              ))}
            </div>

            {!selectedLead && (
              <div style={{ textAlign:"center", padding:"60px 20px", color:"#3a3860" }}>
                <div style={{ fontSize:40, marginBottom:12 }}>✉️</div>
                <div style={{ fontSize:15, fontWeight:600 }}>Select a lead above</div>
                <div style={{ fontSize:12, marginTop:4 }}>AI will generate a personalised message instantly</div>
              </div>
            )}

            {selectedLead && (
              <>
                <div style={{ background:"#0d0d1f", border:"1px solid #1a1a30", borderRadius:16,
                  padding:16, marginBottom:16, display:"flex", gap:12, alignItems:"center" }}>
                  <Avatar initials={selectedLead.initials} size={46} glow={selectedLead.score>=80}/>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:15, fontWeight:800, color:"#e8e4ff", fontFamily:"'Syne',sans-serif" }}>{selectedLead.name}</div>
                    <div style={{ fontSize:12, color:"#4a4870", marginTop:1 }}>{selectedLead.suburb} · {selectedLead.type} · {fmt$(selectedLead.value)}</div>
                    <div style={{ fontSize:11, color:"#3a3860", marginTop:2 }}>{selectedLead.phone} · {selectedLead.email}</div>
                  </div>
                  <ScoreRing score={selectedLead.score}/>
                </div>

                {/* Tone */}
                <div style={{ marginBottom:14 }}>
                  <div style={{ fontSize:9, color:"#4a4870", fontWeight:700, letterSpacing:"1px", marginBottom:8 }}>MESSAGE TONE</div>
                  <div style={{ display:"flex", gap:8 }}>
                    {["Professional","Urgent","Friendly","Bold"].map(t=>(
                      <button key={t} className={`tone-btn${tone===t.toLowerCase()?" active":""}`}
                        onClick={()=>setTone(t.toLowerCase())}
                        style={{ flex:1, padding:"8px 4px", borderRadius:10, fontSize:10, fontWeight:700,
                          background:tone===t.toLowerCase()?"#1e1b4b":"#0d0d1f",
                          border:`1px solid ${tone===t.toLowerCase()?"#4f46e5":"#1a1a30"}`,
                          color:tone===t.toLowerCase()?"#a5b4fc":"#6b6b9a",
                          fontFamily:"'DM Sans',sans-serif" }}>
                        {t}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Buttons */}
                <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:16 }}>
                  <button className="action-btn" onClick={generateMessage} disabled={aiStreaming}
                    style={{ padding:"13px", borderRadius:12, background:"linear-gradient(135deg,#4f46e5,#7c3aed)",
                      border:"none", color:"#fff", fontSize:13, fontWeight:800, cursor:aiStreaming?"wait":"pointer",
                      fontFamily:"'DM Sans',sans-serif", boxShadow:"0 4px 20px #4f46e540",
                      opacity:aiStreaming?0.7:1, display:"flex", alignItems:"center", justifyContent:"center", gap:8 }}>
                    {aiStreaming ? <><Spinner/> Writing...</> : "✨ Write Message"}
                  </button>
                  <button className="action-btn" onClick={generateInsight} disabled={insightStreaming}
                    style={{ padding:"13px", borderRadius:12, background:"linear-gradient(135deg,#0ea5e9,#06b6d4)",
                      border:"none", color:"#fff", fontSize:13, fontWeight:800, cursor:insightStreaming?"wait":"pointer",
                      fontFamily:"'DM Sans',sans-serif", boxShadow:"0 4px 20px #0ea5e940",
                      opacity:insightStreaming?0.7:1, display:"flex", alignItems:"center", justifyContent:"center", gap:8 }}>
                    {insightStreaming ? <><Spinner/> Thinking...</> : "🧠 AI Strategy"}
                  </button>
                </div>

                {/* AI Insight */}
                {aiInsight && (
                  <div style={{ background:"#070e1f", border:"1px solid #0ea5e930", borderRadius:14,
                    padding:16, marginBottom:14, animation:"fadeUp 0.3s ease" }}>
                    <div style={{ fontSize:9, color:"#06b6d4", fontWeight:700, letterSpacing:"1.5px", marginBottom:8 }}>🧠 AI STRATEGY</div>
                    <div style={{ fontSize:13, color:"#93c5fd", lineHeight:1.75 }}>
                      {aiInsight}
                      {insightStreaming && <span style={{ animation:"pulse 0.8s infinite", color:"#06b6d4" }}>▋</span>}
                    </div>
                  </div>
                )}

                {/* Message */}
                {aiMessage && (
                  <div style={{ background:"#0a0a1a", border:"1px solid #1a1a30", borderRadius:14, padding:16, animation:"fadeUp 0.3s ease" }}>
                    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:10 }}>
                      <div style={{ fontSize:9, color:"#4f46e5", fontWeight:700, letterSpacing:"1.5px" }}>✨ AI GENERATED · REAL CLAUDE OUTPUT</div>
                      {!aiStreaming && (
                        <button onClick={()=>{ navigator.clipboard?.writeText(aiMessage); setCopied(true); setTimeout(()=>setCopied(false),2000); showToast("Copied ✓"); }}
                          style={{ padding:"4px 10px", borderRadius:8, background:"#1a1a30", border:"1px solid #2a2a4a",
                            color:copied?"#22c55e":"#6b6b9a", fontSize:10, fontWeight:700, cursor:"pointer",
                            fontFamily:"'DM Sans',sans-serif", transition:"all 0.2s" }}>
                          {copied ? "✓ Copied" : "Copy"}
                        </button>
                      )}
                    </div>
                    <pre ref={msgRef} style={{ fontSize:13, color:"#c4c0e8", lineHeight:1.8, whiteSpace:"pre-wrap",
                      fontFamily:"'DM Sans',sans-serif", minHeight:80 }}>
                      {aiMessage}
                      {aiStreaming && <span style={{ animation:"pulse 0.8s infinite", color:"#4f46e5" }}>▋</span>}
                    </pre>
                    {!aiStreaming && (
                      <div style={{ display:"flex", gap:8, marginTop:14, flexWrap:"wrap" }}>
                        {["📧 Send Email","💬 Send SMS","📋 Save to CRM"].map((btn,i)=>(
                          <button key={i} onClick={()=>showToast(`${btn} — coming soon`)}
                            style={{ padding:"9px 14px", borderRadius:10, fontSize:11, fontWeight:700,
                              background:"#0d0d1f", border:"1px solid #1a1a30", color:"#6b6b9a",
                              cursor:"pointer", transition:"all 0.2s", fontFamily:"'DM Sans',sans-serif" }}>
                            {btn}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </>
            )}
          </div>
        )}

        {/* PREDICT */}
        {tab==="predict" && (
          <div style={{ animation:"fadeUp 0.3s ease" }}>
            <div style={{ background:"linear-gradient(135deg,#0d0d1f,#0a0a1a)", border:"1px solid #1a1a30",
              borderRadius:16, padding:24, marginBottom:16, textAlign:"center" }}>
              <div style={{ fontSize:36, marginBottom:12 }}>🔮</div>
              <div style={{ fontFamily:"'Syne',sans-serif", fontSize:20, fontWeight:800, color:"#fff", marginBottom:8 }}>
                AI Transaction Predictor
              </div>
              <div style={{ fontSize:13, color:"#4a4870", lineHeight:1.7, marginBottom:20, maxWidth:400, margin:"0 auto 20px" }}>
                Real Claude AI analyses your {LEADS.length} leads — motivation signals, contact recency, market timing — and predicts who transacts in the next 30 days.
              </div>
              <button className="action-btn" onClick={runPrediction} disabled={predicting}
                style={{ padding:"15px 32px", borderRadius:12, background:"linear-gradient(135deg,#7c3aed,#4f46e5)",
                  border:"none", color:"#fff", fontSize:14, fontWeight:800, cursor:predicting?"wait":"pointer",
                  fontFamily:"'DM Sans',sans-serif", boxShadow:"0 4px 24px #7c3aed50",
                  opacity:predicting?0.7:1, display:"inline-flex", alignItems:"center", gap:10 }}>
                {predicting ? <><Spinner/> Analysing {LEADS.length} leads...</> : "🔮 Run AI Prediction"}
              </button>
            </div>

            {prediction && (
              <div style={{ background:"#0a0a1a", border:"1px solid #7c3aed40", borderRadius:16,
                padding:20, animation:"fadeUp 0.4s ease" }}>
                <div style={{ fontSize:9, color:"#7c3aed", fontWeight:700, letterSpacing:"1.5px", marginBottom:14 }}>
                  🔮 LIVE AI PREDICTION · REAL CLAUDE OUTPUT
                </div>
                <div style={{ fontSize:14, color:"#c4bfff", lineHeight:1.85, whiteSpace:"pre-wrap" }}>
                  {prediction}
                  {predicting && <span style={{ animation:"pulse 0.8s infinite", color:"#7c3aed" }}>▋</span>}
                </div>
              </div>
            )}
          </div>
        )}
      </main>
    </>
  );
}
