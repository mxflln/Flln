import Anthropic from "@anthropic-ai/sdk";

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();

  const { leads } = req.body;

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  try {
    const stream = await client.messages.stream({
      model: "claude-sonnet-4-5",
      max_tokens: 600,
      system: `You are a predictive real estate AI. Analyse lead data and make bold, specific predictions. Format your response as exactly 3 bullet points starting with •. Each bullet: name, timeframe, and specific reason why.`,
      messages: [{
        role: "user",
        content: `Analyse these leads and predict the top 3 most likely to transact in the next 30 days:

${leads.map(l => `• ${l.name} (${l.type}, ${l.suburb}, score ${l.score}/100, last contact: ${l.lastContact})
  Situation: "${l.notes}"`).join("\n\n")}

Who are the top 3 and exactly why will they transact soon? Be specific about the signals.`
      }]
    });

    for await (const chunk of stream) {
      if (chunk.type === "content_block_delta" && chunk.delta.type === "text_delta") {
        res.write(`data: ${JSON.stringify({ text: chunk.delta.text })}\n\n`);
      }
    }
    res.write("data: [DONE]\n\n");
    res.end();
  } catch (err) {
    res.write(`data: ${JSON.stringify({ error: err.message })}\n\n`);
    res.end();
  }
}
