import Anthropic from "@anthropic-ai/sdk";

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();

  const { lead } = req.body;

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  try {
    const stream = await client.messages.stream({
      model: "claude-sonnet-4-5",
      max_tokens: 400,
      system: `You are a sharp real estate strategy AI. Give specific, bold, actionable advice for Australian agents. Be direct. No fluff. 3-4 sentences max. Think like a top-performing agent, not a consultant.`,
      messages: [{
        role: "user",
        content: `What is the single best strategy for this lead RIGHT NOW?

${lead.name} — ${lead.type} in ${lead.suburb}
Property: ${lead.property} (~$${(lead.value/1000).toFixed(0)}k)
AI Score: ${lead.score}/100
Situation: "${lead.notes}"
Last contact: ${lead.lastContact}

What should the agent do in the next 24 hours to win this deal? Be specific and bold.`
      }]
    });

    for await (const chunk of stream) {
      if (chunk.type === "content_block_delta" && chunk.delta.type === "text_delta") {
        res.write(`data: ${JSON.stringify({ text: chunk.delta.text })}\n\n`);
      }
    }
    res.write("data: [DONE]\n\n");
    res.end();
  } catch (err) {
    res.write(`data: ${JSON.stringify({ error: err.message })}\n\n`);
    res.end();
  }
}
