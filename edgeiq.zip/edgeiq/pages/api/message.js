import Anthropic from "@anthropic-ai/sdk";

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();

  const { lead, tone } = req.body;

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  try {
    const stream = await client.messages.stream({
      model: "claude-sonnet-4-5",
      max_tokens: 600,
      system: `You are Australia's #1 real estate AI assistant for agents. Write hyper-personalised, conversion-optimised outreach messages. Tone: ${tone || "professional"}. Be concise, warm, and specific to their situation. No clichés. Never mention AI. Sign off as "Rebecca".`,
      messages: [{
        role: "user",
        content: `Write a follow-up ${tone === "urgent" ? "urgent " : ""}email for this lead:
Name: ${lead.name}
Type: ${lead.type} (${lead.type === "Seller" ? "wants to sell" : "wants to buy"})
Suburb: ${lead.suburb}, Brisbane QLD
Property: ${lead.property}
Estimated value: $${(lead.value/1000).toFixed(0)}k
AI priority score: ${lead.score}/100
Situation: ${lead.notes}
Last contacted: ${lead.lastContact}

Write a compelling, personalised email that addresses their specific situation. Be human, not robotic.`
      }]
    });

    for await (const chunk of stream) {
      if (chunk.type === "content_block_delta" && chunk.delta.type === "text_delta") {
        res.write(`data: ${JSON.stringify({ text: chunk.delta.text })}\n\n`);
      }
    }
    res.write("data: [DONE]\n\n");
    res.end();
  } catch (err) {
    res.write(`data: ${JSON.stringify({ error: err.message })}\n\n`);
    res.end();
  }
}
